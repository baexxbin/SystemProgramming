#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

#define MAXHOUR_PER_DAY 24
#define MAXMIN_PER_HOUR 60
#define MAXSEC_PER_MIN 60
#define MAXDAY_PER_YEAR 365
#define LEAST_UTC 1970
#define GMT_KOREA 9

#define S_ISRUSR(mode) (((mode)&000400)==000400)
#define S_ISWUSR(mode) (((mode)&000200)==000200)
#define S_ISXUSR(mode) (((mode)&000100)==000100)

#define S_ISRGRP(mode) (((mode)&000040)==000040)
#define S_ISWGRP(mode) (((mode)&000020)==000020)
#define S_ISXGRP(mode) (((mode)&000010)==000010)

#define S_ISROTH(mode) (((mode)&000004)==000004)
#define S_ISWOTH(mode) (((mode)&000002)==000002)
#define S_ISXOTH(mode) (((mode)&000001)==000001)

void checkFileT(int p){
	if (S_ISCHR(p)) printf("c");
	if (S_ISDIR(p)) printf("d");
	if (S_ISBLK(p)) printf("b");
	if (S_ISREG(p)) printf("-");
	if (S_ISLNK(p)) printf("l");
}
void checkUserP(int p){
	if(S_ISRUSR(p))printf("r");
	else printf("-");
	if(S_ISWUSR(p))printf("w");
        else printf("-");
	if(S_ISXUSR(p))printf("x");
        else printf("-");
}
void checkGroupP(int p){
        if(S_ISRGRP(p))printf("r");
        else printf("-");
        if(S_ISWGRP(p))printf("w");
        else printf("-");
        if(S_ISXGRP(p))printf("x");
        else printf("-");
}
void checkOtherP(int p){
        if(S_ISROTH(p))printf("r");
        else printf("-");
        if(S_ISWOTH(p))printf("w");
        else printf("-");
        if(S_ISXOTH(p))printf("x");
        else printf("-");
}

void sec2date(int sec){
       char *month[12] = {"Jan","Feb","Mar","Apr","Jun","Jul","Aug","Oct","Nov","Dec" };
       int days[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
       sec+= GMT_KOREA*MAXMIN_PER_HOUR*MAXSEC_PER_MIN;
       int year,day,hour,min;
       day = (sec/(MAXMIN_PER_HOUR * MAXSEC_PER_MIN * MAXHOUR_PER_DAY));
       year = day / MAXDAY_PER_YEAR + LEAST_UTC;
       hour = (sec % (MAXMIN_PER_HOUR * MAXSEC_PER_MIN * MAXHOUR_PER_DAY)) / (MAXMIN_PER_HOUR * MAXSEC_PER_MIN);
       min = (sec % (MAXMIN_PER_HOUR * MAXSEC_PER_MIN * MAXHOUR_PER_DAY)) / MAXSEC_PER_MIN;
       int i = LEAST_UTC;
       int cnt=0;

       while(i<year+1){
	       if(((i%4)==0 && (i%100) !=0) || (i%400)==0){
		       cnt++;
	       }
	       i++;
       }
       day = (day-cnt+1)%MAXDAY_PER_YEAR;
       i=0;
       while(1){
	       if((day - days[i])<=0){
		       printf(" %s %02d ", month[i],day);
		       break;
	       }else{
		       day -= *month[i];
		       i++;
	       }
       }
       printf(" %02d:%02d ", hour, min);
}


int main(int argv, char* argc[]){
	char* cwd;
	DIR *dp;
	struct dirent *dent;
	struct stat buf;
	//char time[80];
	time_t time;
	int total=0;
	
	cwd = getcwd(NULL,BUFSIZ);
	if((dp = opendir(cwd)) == NULL){
		perror("opendir: Directory");
		exit(1);
	}

	while ((dent = readdir(dp))){
		stat(dent->d_name, &buf);
		total += buf.st_blocks;
	}
	printf("total %d\n", total);
	rewinddir(dp);

	while((dent = readdir(dp))){
		if((dent->d_type == DT_REG)){
			stat(dent->d_name, &buf);
			checkFileT((unsigned int)buf.st_mode);
			checkUserP((unsigned int)buf.st_mode);
			checkGroupP((unsigned int)buf.st_mode);
			checkOtherP((unsigned int)buf.st_mode);
			printf("%4o ", (unsigned int)buf.st_nlink);
			printf("%7d ", (unsigned int)buf.st_size);
			sec2date(time);
			//strftime(time, 80, "%b %d %H:%M", localtime(&(buf.st_mtime)));
			//printf("%s ",time);
			printf("%s\n", dent->d_name);
		}
	}
	closedir(dp);

	return 0;
}
