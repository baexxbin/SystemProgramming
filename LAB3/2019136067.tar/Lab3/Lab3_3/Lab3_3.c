#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>

int str2int(char *str){
	int i=1;
	int v= MYATOI(str[0]);

	while(str[i]!='\0'){
		v = (v*10) + MYATOI(str[i]);
		i++;
	}
	return v
}

char *my_strcat(char *dest, const char *src){
	char *tmp = dest;
	while(*tmp){
		tmp++;
	}
	while(*src){
		*tmp++= *src++;
	}
	*tmp = 0x00;
	
	return dest;
}

void mk_sub(char *dest, char *sub, char *wd){
	int i=0, j=0, k=0;
	while(dest[k]!='\0'){
		if(dest[k]=='/') i++;
		sub[k] = input[k];
		if(i==4) break;
		k++;
	}
	k++;
	while(sub[j]!='\0'){
		sub[k]=output[j];
		k++;
		j++;
	}
}

void prefix(char *link, char *dest){
	int i=0,j=0, k=0;
	while(dest[i]!='\0'){
		if(dest[k]=='/') i++;
		if(i==4) i++;
		k++;
	}
	k++;
	for(j=0; j<4; j++){
		link[j+2] = input[k];
		k++;
	}
}

int main(int argc, char* argv[]){
	DIR *dp;
	struct dirent *dent;
	char *swd;	//서브디렉토리포인터
	char wd[BUFSIZ];
	char link[10]="./";
	int interval = str2int(argv[2]);
	int i=0,k=0;

	if((dp = opendir(argv[1]) == NULL)){
		perror("opendir : input");
		exit(1);
	}
	
	mk_sub(argv[1],argv[3],wd);
	prefix(argv[1],link);
	seekdir(dp,2);

	while((dent = readdir(dp))){
		if(i%interval==0){



	// 문자열을 보내는지 포인터를 보내는지
	argv[3] = my_strcat('/',argv[3]);
	cwd = my_strcat(argv[1],argv[3]);
	mkdir(cwd, 0755);




	


