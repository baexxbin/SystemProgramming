#include <sys/types.h>
#include <sys/stat.h>
#include <sys/errno.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char* argv[]){
	struct stat buf1,buf2;
	int per1,per2;

	if((per1 = access(argv[1], F_OK)) == -1 && errno == ENOENT)
		printf("file.txt no extist.\n");
	if((per2 = access(argv[2], F_OK)) == -1 && errno == ENOENT)
                printf("file2.txt no extist.\n");

	stat(argv[1],&buf1);
	stat(argv[2],&buf2);

	if((int)buf1.st_ino > (int)buf2.st_ino){
		printf("file.txt is bigger\n");
		if(per1 ==0)
			printf("file.txt : Read permission is permitted.\n");
		else if(per1 ==-1 && errno == EACCES)
			printf("file.txt : Read permission is not permitted.\n");
	}else{
		printf("file2.txt is bigger\n");
                if(per2 ==0)
                        printf("file2.txt : Read permission is permitted.\n");
                else if(per2 ==-1 && errno == EACCES)
                        printf("file2.txt : Read permission is not permitted.\n");
	}

	return 0;
}


