#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MYATOI(c) (c-'0')

char *output[]={
	"[%m월 %d일 %a %l:%M %p]"
};	

int myStrcmp(char *s1, char *s2){
	int j=0;
	while(s1[j] != '\0' && s2[j] != '\0'){
		if(s1[j] != s2[j]) return 0;
		j++;
	}
	if(s1[j] != '\0' || s2[j] != '\0') return 0;
	return 1;
}

int main(int argc, char* argv[]){
	struct tm *tm;
	time_t t, t2;
	char buf[257];
	char* tz[]= {"GMT", "KST", "JST", "CST", "MST", "BRT", "CEST", "EAT", "AEST"};
	int tzInt[] = {0, 9, 9, 8, -7, -3, 2, 3, 10};
	int i;

	// default 출력값
	tzset();
	time(&t);
	tm = localtime(&t);
	
	printf("%s : ", tzname[0]);
	strftime(buf, sizeof(buf), output[0], tm);
	printf("%s\n",buf);

	// 입력 출력
	for(i=0;i<9;i++){
		if(myStrcmp(argv[1], tz[i])) break;
	}
	if(i>8){
	       printf("Input Can't Find\n");
	       exit(1);
	}

	t2 = t + (tzInt[i] - 9) * 3600;
	tm = localtime(&t2);

	printf("%s : ", tz[i]);
	strftime(buf, sizeof(buf), output[0],tm);
	printf("%s\n", buf);
	return 0;
}

		

