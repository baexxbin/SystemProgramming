#include <sys/types.h>	// gid_t
#include <grp.h>	// getgrgid, getgrnam, struct group
#include <unistd.h> 	// getgid
#include <stdio.h>
#include <stdlib.h>

int main(void){
	struct group *grp = getgrent();
	int i=0;
	
	do{
		printf("Group Name : %s\n", grp->gr_name);
		printf("GID : %d\n", (int)grp->gr_gid);
		printf("Members : ");
		while(grp->gr_mem[i] != NULL)
			printf("%s ",grp->gr_mem[i++]);
		printf("\n");
	}while((grp == getgrent()) > 0);

	return 0;
}
