#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#define MYATOI(c) (c-'0')

int str2int(char* str){
        int i =1;
        int val = MYATOI(str[0]);

        while(str[i] != '\0'){
                val = (val*10) + MYATOI(str[i]);
                i++;
        }
        return val;
}

int main(int argc, char* argv[]){
	int studentID;
	int getID = str2int(argv[1]);
	char grade[10];
	FILE *rfp, *wfp;
	uid_t uid, euid;

	if((rfp = fopen("/home/professor/grade.db","r")) == NULL){
		perror("fopen : grade.db");
		exit(1);
	}

	if((wfp = fopen(argv[2],"w"))==NULL){
		perror("fopen : write file");
		exit(1);
	}

	// 최초의 UID, EUID 출력
	uid = getuid();
	euid = geteuid();
	printf("uid = %d, euid = %d\n",(int)uid, (int)euid);

	// grade 출력
	while(!feof(rfp)){
		fscanf(rfp, "%d %s", &studentID, grade);
		if(studentID == getID){
			printf("my grade = %s\n", grade);
			setuid(getuid());
			seteuid(getuid());
			printf("uid = %d, euid = %d\n", getuid(), geteuid());
			fprintf(wfp, "%s\n", grade);
			printf("Write the grade to %s\n", argv[2]);

			break;
		}
	}

	fclose(rfp);
	fclose(wfp);
	return 0;
}



