#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int child[2] = {0,};
int main(void){
        pid_t pid, pid2;
        int status;

        switch(pid = fork()){
                case -1 :
                        perror("fork");
                        exit(1);
                        break;
                case 0 :
                        sleep(3);
                        printf("First Child Process\n");

                        child[0] = (int)getpid();
                        printf("My PID: %d\n", child[0]);
                        printf("My Parent's PID: %d\n", (int)getppid());
                        printf("\n");
                        exit(2);
                        break;
                default :
                        pid2 = fork();
                        if(pid2==0){
                                printf("Second Child Process\n");
                                child[1] = (int)getpid();
                                printf("My PID: %d\n", child[1]);
                                printf("My Parent's PID: %d\n", (int)getppid());
                                printf("\n");
                                exit(2);
                                break;
                        }

                        while(wait(&status) != pid)
                                continue;
                        printf("Parent Process\n");
                        printf("My Child's PID: %d, %d\n", (int)pid,(int)pid2);
                        printf("My PID: %d\n", (int)getpid());
                        printf("My Parent's PID: %d\n", (int)getppid());
                        break;
        }
        return 0;
}
