#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#define MYATOI(c) (c-'0')

int str2int(char* str){
        int i =1;
        int val = MYATOI(str[0]);

        while(str[i] != '\0'){
                val = (val*10) + MYATOI(str[i]);
                i++;
        }
        return val;
}

// 날짜 및 시간 출력
char *output[] = {
        "%a %b %e %T %G"
};


//소수찾기 알고리즘
int findPrime(int start, int end){
    int i, j, now = 0, cnt = 0;

    for (i = start; i <= end; i++){
        now = 0;
        if (i < 2){
            now = 1;
        }
        for (j = 2; j < i; j++){
            if (i % j == 0)
            {
                now = 1;
                break;
            }
        }
        if (now == 0)
            cnt++;
    }
    return cnt;
}

int main(int argc, char* argv[]){
        struct tm *tm;
        int startN = str2int(argv[1]), endN = str2int(argv[2]);
        int mid = (startN+endN)/2;
        int res, status;
        char buf[257];
        time_t t, st, et;
        pid_t pid;

        time(&t);
        tm = localtime(&t);

        // Serial algorithm
        printf("[Serial start] ");
        strftime(buf, sizeof(buf), output[0], tm);
        printf("%s\n", buf);
        printf("[Serial] found %d primes\n", findPrime(startN,endN));
        printf("[Serial end] ");
        strftime(buf, sizeof(buf), output[0], tm);
        printf("%s\n", buf);

        // Paralle algorithm
        printf("[Paralle start] ");
        strftime(buf, sizeof(buf), output[0], tm);
        printf("%s\n", buf);

        switch (pid=fork()){
                case -1:
                        perror("fork");
                        exit(1);
                        break;
                case 0:
                        st = (double)clock();
                        res = findPrime(startN,mid);
                        et = (double)clock();

                        printf("[pid = %d] I found %d prime numbers between (%d ~ %d)\n", pid, res, startN, mid);
                        printf("[pid = %d] takes %.3f ms\n", pid, (double)((et-st)/1000.0));
                        printf("[Proc.%d end] ", (int)pid);
                        strftime(buf, sizeof(buf), output[0], tm);
                        printf("%s\n", buf);
                        exit(2);
                        break;
                default:
                        st = (double)clock();
                        res = findPrime(mid+1, endN);
                        et = (double)clock();

                        printf("[pid = %d] I found %d prime numbers between (%d ~ %d)\n", pid, res, mid+1, endN);
                        printf("[pid = %d] takes %.2f ms\n", pid, (double)((et-st)/1000.0));
                        printf("[Proc.%d end] ", (int)pid);
                        strftime(buf, sizeof(buf), output[0], tm);
                        printf("%s\n", buf);

                        while (wait(&status) != pid)
                                continue;
                        break;
        }
        return 0;
}
