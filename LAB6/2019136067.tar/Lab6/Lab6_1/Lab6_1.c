#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[]){

        if(execlp("gcc","gcc", "-o",argv[2],argv[1],(char *)NULL) == -1){
                perror("execl");
                exit(1);
        }

        return 0;
}
