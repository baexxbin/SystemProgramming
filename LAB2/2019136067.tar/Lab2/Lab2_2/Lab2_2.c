#include <stdlib.h>
#include <stdio.h>

int lenFile(FILE *fp){
	int len;
	fseek(fp,0,SEEK_END);
	len = ftell(fp);
	fseek(fp,0,SEEK_SET);

	return len;
}

void writeFile(char buf, FILE *fp, FILE *wfp){
	if(buf>=1 && buf<=9){
		fseek(fp,buf,SEEK_CUR);
	}else{
		fwrite(&buf,sizeof(char),1,wfp);
	}
}


int main(int argc, char* argv[]){
	int cnt=0;
	int lenA,lenB;
	char buf;
	FILE *afp, *bfp, *wfp;

	if((afp = fopen(argv[1], "rb")) == NULL){
		perror("fopen afp");
		exit(1);
	}
	if((bfp = fopen(argv[2], "rb")) == NULL){
		perror("fopen bfp");
		exit(1);
	}
	if((wfp = fopen(argv[3], "wb")) == NULL){
		perror("fopen wfp");
		exit(1);
	}

	lenA = lenFile(afp);
	lenB = lenFile(bfp);

	while(ftell(afp)!=lenA || ftell(bfp)!=lenB){
		if(cnt%2==0){
			fread(&buf, sizeof(char), 1, afp);
			writeFile(buf,bfp,wfp);
		}else{
			fread(&buf, sizeof(char), 1, bfp);
			writeFile(buf,afp,wfp);
		}
		cnt++;
	}

	fclose(afp);
	fclose(bfp);
	fclose(wfp);
	return 1;
}
