#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#define PRINT_ERR_EXIT(_msg) {perror(_msg); exit(1);}

int main(int argc, char* argv[]){
	int rfd;
	FILE *wfp;
	unsigned char buf[3]={0};
	unsigned int num=0;

	rfd = open(argv[1],O_RDONLY);
	if(rfd==-1)PRINT_ERR_EXIT("perror intputFileOpen");
	if((wfp = fopen(argv[2],"w")) == NULL) PRINT_ERR_EXIT("perror outpufFileOpen");
	
	while((read(rfd,buf,3))> 0){
		num = (buf[0]*65536) + (buf[1]*256) + buf[2];
		fprintf(wfp, "%u ",num);
	}

	close(rfd);
	fclose(wfp);
	return 0;
}
