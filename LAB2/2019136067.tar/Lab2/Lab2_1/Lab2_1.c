#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[]){
	int c;
	FILE *rfp, *wfp;

	if((rfp = fopen(argv[1], "r")) == NULL){
		perror("fopen rfp");
		exit(1);
	}

	if((wfp = fopen(argv[2], "w")) == NULL){
		perror("fopen wfp");
		exit(1);
	}

	while ((c = fgetc(rfp)) != EOF){
		if(c>=97 && c<=122){
			fputc(c-32, wfp);
		}else{
			fputc(c, wfp);
		}
	}

	fclose(rfp);
	fclose(wfp);
	return 0;
}



