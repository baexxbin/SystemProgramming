#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define MAX_CHUNK_SIZE 1130
#define MYATOI(c) (c-'0')

int openFile(char *argv){
	int rfd = open(argv, O_RDONLY);
	if(rfd == -1){
		perror("Open File");
		exit(1);
	}
	return rfd;
}

int openWriteFile(char *argv){
	int wfd = open(argv, O_CREAT | O_WRONLY | O_TRUNC, 0644);
	if(wfd == -1){
		perror("Open WriteFile");
		exit(1);
	}
	return wfd;
}

int str2int(char* str){
	int i =1;
	int val = MYATOI(str[0]);

	while(str[i] != '\0'){
		val = (val*10) + MYATOI(str[i]);
		i++;
	}
	return val;
}

int main(int argc, char* argv[]) {
	int rfd, wfd, n;
	char buf[MAX_CHUNK_SIZE];
	clock_t start, end;
	
	int chunkSize = (MAX_CHUNK_SIZE < str2int(argv[3]) ? MAX_CHUNK_SIZE : str2int(argv[3])); 

	rfd = openFile(argv[1]);
	wfd = openWriteFile(argv[2]);

	start = clock();
	while((n=read(rfd,buf,chunkSize)) > 0)
		if(write(wfd, buf, n) != n) perror("Write");

	if(n==-1) perror("Read");
	end = clock();
	
	printf("Copy %s to %s\n", argv[1],argv[2]);
	printf("chunkSize: %d, speed: %lf\n sec ", chunkSize,(double)(end-start)/CLOCKS_PER_SEC);

	close(rfd);
	close(wfd);
	return 0;
}
