#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define BUF_SIZE 1024
#define ON_TIMER {startTime = clock(); }
#define OFF_TIMER {endTime = clock();}
#define PRINT_TIMER printf("It takes %f seconds\n", 
