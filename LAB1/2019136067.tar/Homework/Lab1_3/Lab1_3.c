#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

void go(int wfd, const char tmp){
	write(wfd, &tmp, 1);
}

int main(int argc, char *argv[]){
	int rfd, wfd,n;
	char tmp=0;
	clock_t start, end;
	
	rfd = open(argv[1], O_RDONLY);
        if(rfd == -1){
                perror("Open File");
                exit(1);
        }
	
	wfd = open(argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0644);
        if(wfd == -1){
                perror("Open WriteFile");
                exit(1);
        }

	start = clock();
	while((n = read(rfd, &tmp, 1) > 0)){
		if(tmp>=32 && tmp<=127){
			go(wfd, tmp);
			printf("%c", tmp);
		}else{
			if(lseek(rfd, tmp%32, SEEK_CUR) == -1){
				break;
			}
		}
	}
	end = clock();
	
	printf("It takes %lf seconds", (double)(end-start)/CLOCKS_PER_SEC);
       
	close(rfd);
	close(wfd);
	return 0;
}	


