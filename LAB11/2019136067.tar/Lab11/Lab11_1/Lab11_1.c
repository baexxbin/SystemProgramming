#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdlib.h>
#include <sys/wait.h>

union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
};

int initsem(key_t semkey){
	union semun semunarg;
	int status = 0;
    int semid;

	semid = semget(semkey, 1, IPC_CREAT | IPC_EXCL | 0600);
	if (semid == -1){
		if (errno == EEXIST) semid = semget(semkey, 1, 0);
	}
	else{
		semunarg.val = 1;
		status = semctl(semid, 0, SETVAL, semunarg);
	}

	if (semid == -1 || status == -1){
		perror("initsem");
		return (-1);
	}

	return semid;
}

int semlock(int semid){
	struct sembuf buf;

	buf.sem_num = 0;
	buf.sem_op = -1;
	buf.sem_flg = SEM_UNDO;
	if (semop(semid, &buf, 1) == -1){
		perror("semlock failed");
		exit(1);
	}
	return 0;
}

int semunlock(int semid){
	struct sembuf buf;

	buf.sem_num = 0;
	buf.sem_op = 1;
	buf.sem_flg = SEM_UNDO;
	if (semop(semid, &buf, 1) == -1){
		perror("semunlock failed");
		exit(1);
	}
	return 0;
}

void semhandle(){
	FILE *fp;
	int n, semid;
    int number = (int)getpid();

	if ((semid = initsem(1)) < 0) exit(1);
	semlock(semid);

	if ((fp = fopen("./paper.txt", "a")) == NULL){
		perror("open");
		exit(1);
	}

	if ((n = fprintf(fp, "%d ", number)) == -1){
		perror("write");
		exit(1);
	}
	fclose(fp);
	sleep(1);
	printf("%d번 손님 대기 등록 완료했습니다.\n", number);
	
    semunlock(semid);
	exit(0);
}

int main(int argc, char *argv[]){
	int n = atoi(argv[1]);
	pid_t pid;

	printf("번호표를 발급합니다.\n");

	for (int i = 0; i < n; i++){
        if ((pid = fork()) == 0) semhandle();
    }
		
	while (wait(&pid) != -1){}
    
	return 0;
}
