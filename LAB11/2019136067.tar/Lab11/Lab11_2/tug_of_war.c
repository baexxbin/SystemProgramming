#include <sys/types.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

int main (void ){
    key_t key;
    int shmid;
    pid_t pid;
    char buf [1024];
    int team1 = 6, team2 = 3 ;
    int (*shmaddr)[2];

    srand ((unsigned int)time (NULL));
    key = ftok ("shmfile", 1);
    shmid = shmget (key , 1024 , IPC_CREAT |0666);
    shmaddr = shmat (shmid, NULL, 0);
    *shmaddr[0]=10;
    *shmaddr[1]=0;

    while (!(*shmaddr[0] <=0 || *shmaddr[0] >= 20)){
        *shmaddr[0] -= team1;
        team1 -= (rand()%2);
        *shmaddr[0] += team2;
        team2 += (rand()%2);
        *shmaddr[1] += 1;
        sleep(1);
    }
    shmdt (*shmaddr);

    return 0 ;
}