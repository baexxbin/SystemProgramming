#include<sys/types.h>
#include<signal.h>
#include<sys/mman.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include <time.h>

int main(void){
    key_t key;
    int shmid;
    pid_t pid;
    char buf[1024];
    int team1 = 6, team2= 3;
    int (*shmaddr)[2];

    key = ftok("shmfile", 1);
    shmid = shmget(key, 1024, IPC_CREAT|0666);

    shmaddr = shmat(shmid, NULL, 0);

    while(!(*shmaddr[0] <= 0 || *shmaddr[0] >= 20)){
        printf("phase : %2d |A", *shmaddr[1]);
        
        for(int i = 0; i <= *shmaddr[0]; i++){
            printf("=");
        }
        printf("||");
        
        for(int i = 20; i > *shmaddr[0];i--){
            printf("=");
        }
        printf("B\n");
        sleep(1);
    }

    if(*shmaddr[0] <= 0) printf("A team win!\n");
    else if (*shmaddr[0] >= 20) printf("B team win!\n");
    
    shmdt(*shmaddr);
    shmctl(shmid, IPC_RMID,NULL);
    return 0;
}