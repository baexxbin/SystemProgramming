#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define CHECK_MMAP_SUCCESS(_addr)\
	if(_addr == MAP_FAILED){\
		perror("mmap");\
		exit(1);\
	}\

int cnt_len(char *str){
    int len=0;
    while (str[len]){ len++; }
    return len;
}

int isSame(char *s1, char *s2){
    while (*s1 != '\0' || *s2 != 0){
        if (*s1 > * s2) return 1;
        if (*s1 < *s2) return -1;
        
        s1++;
        s2++;
    }
 
    return 0;
}

int main(int argc, char* argv[]){
    int fd;
    FILE *rfp;
    caddr_t addr;
    char buf[BUFSIZ];

    if((fd = open(argv[1], O_RDWR)) == -1){
        perror("open");
        exit(1);
    }

    if((rfp = fopen(argv[2], "r")) == NULL){
        perror("read file open");
        exit(1);
    }

    int pageSize = getpagesize();

    addr = mmap(NULL, pageSize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, (off_t)0);
    CHECK_MMAP_SUCCESS(addr);

    fgets(buf,BUFSIZ,rfp);

    close(fd);
    fclose(rfp);

    int pid=0;
    switch (pid=fork()){
    case -1:
        perror("fork");
        exit(1);
        break;
    
    case 0:     // 자식프로세스
        for(int j=0; j<cnt_len(buf); j++){
            addr[j] = buf[j];
            sleep(1);
        }
        // if((c = fgetc(rfp)) != EOF){
        //     addr[i++] = c;
        // }
        break;

    default:    // 부모프로세스
        while (1){
            if(isSame(addr,buf)!=0){
                printf("도르마무 mapping을 하러 왔다\n");
                printf("%s\n", addr);
                sleep(1);
            }else{
                printf("\n%s\n",addr);
                printf("발동!\n");
                printf("도르마무를 물리쳤다!\n");
                break;
            }
        }
    }
    return 0;
}