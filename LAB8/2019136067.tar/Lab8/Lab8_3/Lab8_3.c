#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

int on = -1;
int mode=0;

void signal_handler(int signo){ printf("- Received signal: %s\n", strsignal(signo));}

void user_handler(int signo){
    if(on==-1){
        mode=-1;
        on=0;
        printf("Do Not Disturb mode on!\n");
    }else{
        printf("Do Not Disturb mode off!\n");
        printf("[During the DND mode]\n");
        mode=1;
        on=-1;
    }
}

int main(void){
    sigset_t block;     //sigset 변수
    sigemptyset(&block);

    if(signal(SIGUSR1,user_handler)==SIG_ERR){
        perror("signal user_handler");
        exit(1);
    }

    for(int i=1; i<=SIGRTMAX; i++){
        if(i!=9 && i!=10 && i!=19) sigaddset(&block,i); //시그널 등록
    }

    while (1){
        if(mode==-1){       // 방해금지 모드
            for(int i=1; i<SIGRTMAX;i++){
                if(i!=9 && i!=10 && i!=19){
                    signal(i,signal_handler);
                }
            }
            sigprocmask(SIG_SETMASK, &block, (sigset_t *)NULL);      // 시그널 blocking
            mode=0;
        }else if(mode==1){  // 방해금지 모드아님
            sigprocmask(SIG_UNBLOCK,&block,(sigset_t *)NULL);
            for(int i=1; i<=SIGRTMAX; i++){
                if(i!=9 && i!=10 && i!=19) signal(i,SIG_DFL);       // default handler처리
            }
            mode=0;
        }
    }
    return 0;
}