#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define CHECK_MMAP_SUCCESS(_addr)\
	if(_addr == MAP_FAILED){\
		perror("mmap");\
		exit(1);\
	}\

int main(void){
	int fd;
	caddr_t addr;
	char msg[20], *chat;
	char fileName[255] = "chat.txt";

	if((fd=open(fileName,O_CREAT | O_RDWR | O_APPEND, 0644)) == -1){
		perror("open");
		exit(1);
	}

	int pageSize = getpagesize();
	ftruncate(fd, 100);
	addr = mmap(NULL, pageSize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, (off_t)0);
	CHECK_MMAP_SUCCESS(addr);
	close(fd);

	// 메세지 전송
	printf("[발신] ");
	scanf("%s",msg);

	int i=1;
	chat = msg;
	while(*chat){
		addr[i++] = *chat++; 
	}
	addr[i] = '\0';	// 문자열의 끝
	addr[0]=1;		// user1이 메세지 보냄표시

	// 메세지 수신
	sleep(1);
	while (1){
		if(addr[0]==2){	// user2가 메세지 보냄
		printf("[수신] ");
		for(i; addr[i]!='\0'; i++){
			printf("%c",addr[i]);
		}
		printf("\n");
		addr[0] = 1;
		break;
		}
	}

	return 0;
}


