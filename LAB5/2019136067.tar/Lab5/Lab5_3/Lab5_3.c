#include "DSTimer.h"

int main(void){
	time_t t;

	myTimer_init(2);
	
	myTimer_on(0);
	for(int i=0; i<9999999; i++){
		time(&t);
	}

	myTimer_off(0);
	sleep(2);

	myTimer_on(1);
	for(int i=0; i<888888; i++){
		time(&t);
	}
	myTimer_off(1);
	sleep(2);

	printf("[myTimer]\n");
	myTimer_print();
	myTimer_finalize();

	return 0;
}

