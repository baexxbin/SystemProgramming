#ifndef HEADER_H
# define HEADER_H

# include <sys/time.h>
# include <time.h>
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>

# define MAX_SIZE 20
struct timeval *start[MAX_SIZE], *end[MAX_SIZE];
int size;
double *tm;

int myTimer_init(int numTimers){
	if(numTimers > MAX_SIZE) return 0;
	size = numTimers;

	tm = (double *)malloc(sizeof(double) * numTimers);
	if(tm==NULL){
	       printf("malloc error");
	       exit(1);
	}

	for(int i=0; i<size; i++){
		start[i] = malloc(sizeof(struct timeval));
		end[i] = malloc(sizeof(struct timeval));
	}
	return 1;
}

int myTimer_finalize(void){
	for(int i=0; i < size; i++){
		free(start[i]);
		free(end[i]);
	}
	free(tm);
	return 1;
}

int myTimer_on(int timerID){
	if(gettimeofday((start[timerID]), NULL) == -1)
		return 0;
	return 1;
}
	
int myTimer_off(int timerID){
	if(gettimeofday((end[timerID]), NULL) == -1)
		return 0;

	tm[timerID] += (end[timerID]->tv_usec - start[timerID]->tv_usec) / 1000.0;
	tm[timerID] += (end[timerID]->tv_sec - start[timerID]->tv_sec)*1000;
	return 1;
}

int myTimer_print(void){
	for(int i=0; i<size; i++){
		printf("Timer %d : %.2f ms\n", i, tm[i]);
	}
	return 1;
}
#endif
