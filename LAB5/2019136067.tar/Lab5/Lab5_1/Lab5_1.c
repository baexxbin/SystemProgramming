#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#define MYATOI(c) (c-'0')

int str2int(const char* str){
        int i =1;
        int val = MYATOI(str[0]);

        while(str[i] != '\0'){
                val = (val*10) + MYATOI(str[i]);
                i++;
        }
        return val;
}

int main(int argc, char* argv[]){
	printf("PID : %d\n", (int)getpid());
	printf("PGID : %d\n", (int)getpgrp());
	printf(" ------------- \n");

	pid_t pgid = (pid_t)str2int(argv[1]);
	setpgid(0,pgid);

	printf("PID : %d\n", (int)getpid());
	printf("PGID : %d\n", (int)getpgrp());

	while(1){
	}

	return 0;
}
		
