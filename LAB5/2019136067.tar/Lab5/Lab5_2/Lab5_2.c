#include <sys/types.h>
#include <sys/times.h>
#include <time.h>
#include <fcntl.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#define MAX_CHUNK_SIZE 16
#define MYATOI(c) (c-'0')

int openFile(char *argv){
        int rfd = open(argv, O_RDONLY);
        if(rfd == -1){
                perror("Open File");
                exit(1);
        }
        return rfd;
}

int openWriteFile(char *argv){
        int wfd = open(argv, O_CREAT | O_WRONLY | O_TRUNC, 0644);
        if(wfd == -1){
                perror("Open WriteFile");
                exit(1);
        }
        return wfd;
}

int str2int(char* str){
        int i =1;
        int val = MYATOI(str[0]);

        while(str[i] != '\0'){
                val = (val*10) + MYATOI(str[i]);
                i++;
        }
        return val;
}

int main(int argc, char* argv[]){
	struct tms mytms;
	clock_t t1,t2; // 얻어온 clock_t를 저장할 공간
	int rfd, wfd, n, cost;
	double ut, st;
	char buf[MAX_CHUNK_SIZE];

	int chunkSize = MAX_CHUNK_SIZE;

        rfd = openFile(argv[1]);
        wfd = openWriteFile(argv[2]);

        if((t1 = times(&mytms)) == -1) {perror("times start"); exit(1);}

	sleep(5);


        while((n=read(rfd,buf,chunkSize)) > 0)
                if(write(wfd, buf, n) != n) perror("Write");

        if(n==-1) perror("Read");
        
	if((t2 = times(&mytms)) == -1) {perror("times end"); exit(1);}
	
	ut = (double)mytms.tms_utime / sysconf(_SC_CLK_TCK);
	st = (double)mytms.tms_stime / sysconf(_SC_CLK_TCK);
	cost = (ut*100)+(st*200);

	printf("Read time : %.3f sec\n", (double)(t2-t1) / sysconf(_SC_CLK_TCK));
	printf("User time : %.3f sec\n", ut);
	printf("System time : %.3f sec\n", st);
	printf("사용료는 %d원 입니다.\n", cost); 

	return 0;
}



