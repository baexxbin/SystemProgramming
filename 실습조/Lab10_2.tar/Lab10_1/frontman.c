#include <sys/msg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

struct quizbuf {
        long mtype;
        char mtext[80];
};

int main(void) {
        key_t key;
        int msgid;
        pid_t mypid;
        struct quizbuf mesg;
        struct msqid_ds msqstat;
        int answer[] = {10, 456, 4};
        int input;
        char* quiz[] = {"오징어 다리 개수는?", "오징어 게임 최종 우승자 번호는?", "네모 달고나의 꼭짓점 개수는?"};

        key = ftok("keyfile", 1);
        msgid = msgget(key, IPC_CREAT|0644);
        if (msgid == -1) {
                perror("msgget");
                exit(1);
        }

        mesg.mtype = 1;
        mypid = getpid();

        printf("ㅇㅅㅁ 오징어 게임 시작 ㅇㅅㅁ \n\n");

        for(int i = 0; i < 3; i++){
            strcpy(mesg.mtext, quiz[i]);

            if (msgsnd(msgid, (void *)&mesg, 80, IPC_NOWAIT) == -1) {
                        perror("msgsnd");
                        exit(1);
                }

                printf(">> %d 라운드 문제 전송\n", i+1);
                while(1) {
                        if (msgctl(msgid, IPC_STAT, &msqstat) == -1) {
                                perror("msgctl");
                                exit(1);
                        }
                        if (mypid != msqstat.msg_lspid) {
                                msgrcv(msgid, &mesg, 80, 0, 0);
                                input = atoi(mesg.mtext);
                                if (answer[i] == input) {
                                        printf("성공!\n%d번 참가자 %d라운드 통과\n\n",(int)msqstat.msg_lspid, i+1);
                                        break;
                                }
                                else {
                                        printf("%d번 참가자 탈락\n\n", (int)msqstat.msg_lspid);
                                        printf("탕\n");
                                        kill((int)msqstat.msg_lspid, SIGKILL);
                                        kill((int)mypid, SIGKILL);
                                }
                        }
                }


        }
        return 0;

}