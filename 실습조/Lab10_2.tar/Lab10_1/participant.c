#include <sys/msg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

struct quizbuf {
        long mtype;
        char mtext[80];
};

int main(void) {
        key_t key;
        struct quizbuf mesg;
        int msgid;
        char answer[80];
        pid_t mypid;

        key = ftok("keyfile", 1);
        if ((msgid = msgget(key, 0)) < 0) {
                perror("msgget");
                exit(1);
        }

        mesg.mtype = 1;

        printf("ㅇㅅㅁ 당신은 오징어 게임에 참가하셨습니다 ㅇㅅㅁ\n\n");
        
        for (int i = 0; i < 3; i++) {
                msgrcv(msgid, &mesg, 80, 0, 0);
                printf(">> %d라운드. ",i+1);
                printf("%s : ", mesg.mtext);
                scanf("%s", answer);
                printf("\n");

                strcpy(mesg.mtext, answer);
                if (msgsnd(msgid, (void *)&mesg, 80, IPC_NOWAIT) == -1) {
                    perror("msgsnd");
                    exit(1);
                }
                sleep(1);
        }
        printf("456억원 획득!!!\n");

        return 0;
}