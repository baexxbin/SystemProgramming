#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]){
    int pd, n;
    int num = atoi(argv[2]);
    char *msg = argv[1];

    if((pd = open("./pipeFile", O_WRONLY)) == -1){
        perror("open");
        exit(1);
    }

    if(write(pd, argv[2], strlen(argv[2])+1)==-1){
        perror("write");
        exit(1);
    }

    

    printf("직녀 =====\n");
    sleep(1);

    for(int i=0; i<num; i++){
        printf("견우에게 :  %s\n", msg);
        if(write(pd, msg, 5)==-1){
            perror("write"); exit(1);
        }
        sleep(1);
    }
    write(pd,"\0",1);
    close(pd);

    return 0;
}