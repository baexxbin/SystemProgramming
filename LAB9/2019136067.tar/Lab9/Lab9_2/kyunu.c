#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(void){
    int pd, num;
    char inmsg[80];
    char cnum[10];

    printf("견우 =====\n");
    if((pd = open("./pipeFile", O_RDONLY)) == -1){
        perror("open");
        exit(1);
    }

    read(pd,cnum,10);
    num = atoi(cnum);

    while (1){
        sleep(1);
        read(pd,inmsg,5);

        if(strcmp("\0",inmsg)==0) break;

        printf("직녀에게 : ");

        if(strcmp(inmsg,"ping")==0){
            printf("pong\n");
        }else if(strcmp(inmsg,"tiki")==0){
            printf("taka\n");
        }else{
            printf("what?\n");
        }
    }
    
    close(pd);
    return 0;
}