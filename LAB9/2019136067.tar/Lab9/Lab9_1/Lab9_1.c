#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(void){
    FILE *fp;
    char buf[BUFSIZ] = "무~야~호~~~~~~!";

    //fp = popen("cat < buf > sample.out","w");
    fp = popen("./sample.out", "w");
    if(fp==NULL){
        fprintf(stderr, "popen failed\n");
        exit(1);
    }

    fwrite(buf, sizeof(char), sizeof(buf), fp);
    pclose(fp);
    
    return 0;
}