#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(void){
    char buf[BUFSIZ];

    memset(buf, 0, sizeof(buf));
    scanf("%s", buf);

    printf("무~한~~~~~~!\n");
    sleep(1);
    printf("%s\n", buf);
    
    return 0;
}